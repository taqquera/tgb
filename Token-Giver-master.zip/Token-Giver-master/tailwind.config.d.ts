declare module 'tailwind.config.js' {
  const config: any;
  export default config;
}