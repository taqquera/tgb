'use client';

import { ErrorPage } from '@/components/ErrorPage';

export default ErrorPage;
