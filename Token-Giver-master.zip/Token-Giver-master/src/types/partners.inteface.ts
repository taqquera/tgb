export interface PartnersInteface {
  id: number
  name: string
  iconUrl: string
  bgUrl: string | null
}
