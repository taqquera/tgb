export enum LeadersTypeEnum {
  TOKEN = 'token',
  DEAMOND = 'deamond',
  REFERRAL = 'referral',
}
